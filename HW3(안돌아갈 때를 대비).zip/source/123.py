import os
import torch
from model import CharRNN, CharLSTM
from dataset import Shakespeare

def softmax_temperature(logits, temperature=1.0):
    """
    Apply softmax function with temperature to logits
    
    Args:
        logits: Logits before softmax
        temperature: Temperature parameter T
        
    Returns:
        Probabilities after applying softmax
    """
    adjusted_logits = logits / temperature
    probabilities = torch.exp(adjusted_logits) / torch.sum(torch.exp(adjusted_logits), dim=1).unsqueeze(1)
    return probabilities

def generate(model, seed_characters, temperature, char_to_idx, idx_to_char, length=100):
    """ Generate characters

    Args:
        model: trained model
        seed_characters: seed characters
        temperature: T
        char_to_idx: dictionary mapping from character to index
        idx_to_char: dictionary mapping from index to character
        length: number of characters to generate (default is 100)

    Returns:
        samples: generated characters
    """
    model.eval()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)

    input_chars = [char_to_idx[char] for char in seed_characters]
    input_tensor = torch.tensor(input_chars, dtype=torch.long).unsqueeze(0).to(device)

    hidden = model.init_hidden(1)
    if isinstance(hidden, tuple):
        hidden = (hidden[0].to(device), hidden[1].to(device))
    else:
        hidden = hidden.to(device)

    samples = seed_characters

    with torch.no_grad():
        for _ in range(length):
            output, hidden = model(input_tensor, hidden)
            probabilities = softmax_temperature(output.squeeze(), temperature)
            top_i = torch.multinomial(probabilities, 1).item()
            char = idx_to_char[top_i]
            samples += char

            input_tensor = torch.tensor([[top_i]], dtype=torch.long).to(device)

    return samples

if __name__ == "__main__":
    # Load the trained model
    base_dir = os.path.dirname(os.path.abspath(__file__))
    model_path = os.path.join(base_dir, 'best_model.pth')
    checkpoint = torch.load(model_path, map_location='cpu')
    
    # Initialize the model
    model_type = checkpoint['model_type']
    input_size = checkpoint['input_size']
    hidden_size = checkpoint['hidden_size']
    output_size = checkpoint['output_size']
    n_layers = checkpoint['n_layers']
    dropout_prob = checkpoint['dropout_prob']

    if model_type == 'CharRNN':
        model = CharRNN(input_size, hidden_size, output_size, n_layers, dropout_prob)
    else:
        model = CharLSTM(input_size, hidden_size, output_size, n_layers, dropout_prob)

    model.load_state_dict(checkpoint['model_state_dict'])

    # Load dataset to get char_to_idx and idx_to_char
    dataset_path = os.path.join(base_dir, '..', 'dataset', 'shakespeare_train.txt')
    dataset = Shakespeare(dataset_path)
    char_to_idx = dataset.char_to_idx
    idx_to_char = dataset.idx_to_char

    # Generate text
    seed_characters = ["T", "H", "A", "R", "G"]
    temperatures = [0.2, 0.5, 1.0, 1.5]  # �پ��� �µ� ��
    length = 100

    for seed in seed_characters:
        for temperature in temperatures:
            generated_text = generate(model, seed, temperature, char_to_idx, idx_to_char, length)
            print(f"Seed: {seed}, Temperature: {temperature}\nGenerated Text: {generated_text}\n")
